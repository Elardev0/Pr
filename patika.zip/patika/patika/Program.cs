﻿byte a = 1;
sbyte b = 2;

short c = 3;
ushort d = 4;

Int16 e = 5;
int  f = 6;
Int32 g = 7;
Int64 h = 8;
uint i = 9;

long j = 10;
ulong k = 11;

//Reel sayılar
float l = 12f;
double m = 13;
decimal n = 14;

char ch = 'A';
string str = "ABC";

bool b1 = true;
bool b2 = false;

DateTime dateTime = DateTime.Now;

object obj = "Hello World!";
object obj2 = 2.5;

string str2 = string.Empty;
string str3 = null;
